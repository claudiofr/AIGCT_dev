AI Genomics CollecTive (AIGCT) is a platform for systematically 
evaluating ML/AI models of variant effects across the spectrum of 
genomics-based precision medicine.
