import context  # noqa: F401


def test_validate_pks(ve_data_validator):
    result = ve_data_validator.validate_pks()
    pass


